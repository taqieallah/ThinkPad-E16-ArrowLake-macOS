#!/usr/bin/env python3
"""Verify sites.json against an extracted x86_64 AppleParavirtGPU Mach-O.

Checks, independently of the generator:
  * Mach-O is a thin x86_64 kext bundle with the expected LC_UUID;
  * every BAR0 site exists at its file offset, with the recorded bytes, and the
    VA <-> __TEXT file-offset relation is exact;
  * every recorded site/instruction/next-boundary address is an instruction
    boundary in BOTH the supplied apv.dis disassembly and a fresh
    llvm-objdump run over the same Mach-O;
  * every patch span starts on the site, is >= 5 bytes, consists only of whole
    instructions, ends on an instruction boundary, and its recorded original
    bytes equal the concatenation of the real instructions;
  * the replacement template is 5-byte CALL + padding of the right length;
  * memory operands decode to the recorded BAR0 offset (disp + 0x1000) and the
    base register is the destination of the recorded struct-field pointer load;
  * the 19-entry prior list decodes to the recorded instructions/verdicts.

Usage:  python3 verify-sites.py <AppleParavirtGPU> [-v]
Writes PASS/FAIL summary to stdout; exit code 0 == PASS.
"""
import argparse, json, re, struct, subprocess, sys, uuid
from pathlib import Path

HERE = Path(__file__).resolve().parent
DEFAULT_JSON = HERE / 'sites.json'
DEFAULT_DIS = HERE / 'apv.dis'          # copied from e16-work/apv/apv.dis
LLVM_OBJDUMP = None

EXPECTED_UUID = uuid.UUID('0cae9e29-bc33-315d-82a7-a7d30e9b971e')
LC_UUID, LC_SEGMENT_64 = 0x1b, 0x19
CPU_X86_64, MH_KEXT_BUNDLE = 0x01000007, 11

def fail(msg):
    raise SystemExit('FAIL: ' + msg)

def u32(b, o): return struct.unpack_from('<I', b, o)[0]
def u64(b, o): return struct.unpack_from('<Q', b, o)[0]

def parse_macho(data):
    magic = u32(data, 0)
    if magic != 0xFEEDFACF:
        fail(f'not a thin little-endian 64-bit Mach-O (magic {magic:#x})')
    cputype, cpusubtype, filetype, ncmds, sizeofcmds, flags, reserved = struct.unpack_from('<7I', data, 4)
    if cputype != CPU_X86_64 or filetype != MH_KEXT_BUNDLE:
        fail(f'expected x86_64 KEXTBUNDLE, got cputype {cputype:#x} filetype {filetype}')
    off = 32; end = 32 + sizeofcmds
    if end > len(data): fail('truncated load commands')
    image_uuid = None; text = None; sections = {}
    for _ in range(ncmds):
        if off + 8 > end: fail('truncated load command')
        cmd, cmdsize = struct.unpack_from('<II', data, off)
        if cmdsize < 8 or off + cmdsize > end: fail('bad load command size')
        if cmd == LC_UUID:
            if cmdsize != 24 or image_uuid is not None: fail('invalid/duplicate LC_UUID')
            image_uuid = uuid.UUID(bytes=data[off + 8:off + 24])
        elif cmd == LC_SEGMENT_64:
            segname = data[off + 8:off + 24].rstrip(b'\0').decode()
            vmaddr, vmsize, fileoff, filesize = struct.unpack_from('<4Q', data, off + 24)
            nsects = u32(data, off + 64)
            if fileoff + filesize > len(data): fail('segment past EOF')
            if segname == '__TEXT':
                if text is not None: fail('duplicate __TEXT segment')
                text = dict(vmaddr=vmaddr, vmsize=vmsize, fileoff=fileoff, filesize=filesize)
                so = off + 72
                for _ in range(nsects):
                    name = data[so:so+16].rstrip(b'\0').decode()
                    addr, size, offset = u64(data, so+32), u64(data, so+40), u32(data, so+48)
                    sections[name] = dict(addr=addr, size=size, offset=offset)
                    so += 80
        off += cmdsize
    if off != end: fail('load-command chain length mismatch')
    if image_uuid != EXPECTED_UUID:
        fail(f'unexpected image UUID {image_uuid} (expected {EXPECTED_UUID})')
    if text is None: fail('no __TEXT segment')
    if sections.get('__text', {}).get('offset') != 0x600:
        fail('__text file offset is not 0x600')
    return dict(text=text, sections=sections, uuid=image_uuid)

def run_objdump(binary):
    global LLVM_OBJDUMP
    LLVM_OBJDUMP = subprocess.run(['xcrun', '--find', 'llvm-objdump'],
                                  capture_output=True, text=True, check=True).stdout.strip()
    p = subprocess.run([LLVM_OBJDUMP, '-d', '--print-imm-hex', str(binary)],
                       capture_output=True, text=True)
    if p.returncode != 0: fail('llvm-objdump failed: ' + p.stderr[-500:])
    insns = {}; order = []
    for line in p.stdout.splitlines():
        m = re.match(r'^([0-9a-f]+):(.*)$', line)
        if not m: continue
        va = int(m.group(1), 16); rest = m.group(2)
        if '\t' in rest:
            bpart, text = rest.split('\t', 1)
        else:
            mm = re.match(r'^(.*?\S)\s{2,}(\S.*)$', rest.strip())
            if not mm: continue
            bpart, text = mm.group(1), mm.group(2)
        toks = bpart.split()
        if not toks or any(not re.fullmatch(r'[0-9a-f]{2}', t) for t in toks): continue
        raw = bytes(int(t, 16) for t in toks)
        insns[va] = (raw, text.split('##')[0].strip())
        order.append(va)
    if not insns: fail('objdump produced no instructions')
    return insns, order

def parse_apv_dis(binary_name):
    if not DEFAULT_DIS.exists():
        fail(f'missing {DEFAULT_DIS} (copy apv.dis next to this script)')
    addrs = set(); funcs = []
    cur = None
    pat_insn = re.compile(r'^([0-9a-f]{8,16}):')
    pat_func = re.compile(r'^([0-9a-f]{16}) <(.+)>:$')
    for line in DEFAULT_DIS.read_text(errors='replace').splitlines():
        mf = pat_func.match(line)
        if mf:
            cur = dict(va=int(mf.group(1), 16), name=mf.group(2)); funcs.append(cur); continue
        mi = pat_insn.match(line)
        if mi:
            addrs.add(int(mi.group(1), 16))
    if not addrs: fail('apv.dis has no instructions')
    return addrs

def parse_memop(text):
    """return (base, disp) of the first base+disp memory operand, or None"""
    m = re.search(r'(-?0x[0-9a-f]+)?\((%[a-z0-9]+)\)', text)
    if not m: return None
    disp = int(m.group(1), 16) if m.group(1) else 0
    return m.group(2), disp

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('image', type=Path)
    ap.add_argument('--json', type=Path, default=DEFAULT_JSON)
    ap.add_argument('-v', '--verbose', action='store_true')
    args = ap.parse_args()

    data = args.image.read_bytes()
    macho = parse_macho(data)
    text = macho['text']
    text_vmaddr, text_fileoff, text_filesize = text['vmaddr'], text['fileoff'], text['filesize']
    sites = json.loads(args.json.read_text())
    insns, order = run_objdump(args.image)
    apv_addrs = parse_apv_dis(args.image.name)
    # Remove symbol-derived pseudo instructions at padding bytes: apv.dis
    # addresses are exactly the instruction boundaries objdump reports.
    apv_addrs &= set(order)
    if apv_addrs != set(order):
        # informational only: apv.dis may have been produced from an equivalent
        # binary; require it to cover every address we actually use below.
        missing = set(order) - apv_addrs
        if args.verbose and missing:
            print(f'note: apv.dis is missing {len(missing)} instruction boundaries present in objdump')
    va2idx = {va: i for i, va in enumerate(order)}
    n_sites = n_ptr = n_pat = 0
    span_starts = set()
    checks = 0

    def at(va):
        if va not in insns: fail(f'{va:#x} is not an instruction boundary in llvm-objdump')
        if apv_addrs and va not in apv_addrs: fail(f'{va:#x} is not an instruction boundary in apv.dis')
        return insns[va]

    def check(cond, msg):
        nonlocal checks
        checks += 1
        if not cond: fail(msg)

    # ---- image block ----
    img = sites['image']
    check(img['uuid'].lower() == str(macho['uuid']).lower(), 'sites.json UUID mismatch')
    check(img['text_vmaddr'] == text_vmaddr, 'sites.json __TEXT vmaddr mismatch')
    check(img['text_filesize'] == text_filesize, 'sites.json __TEXT filesize mismatch')
    sec = macho['sections']['__text']
    check(sec['addr'] == img['text_section_va'] and sec['offset'] == img['text_section_file_offset']
          and sec['size'] == img['text_section_size'], '__text section geometry mismatch')

    for s in sites['sites']:
        n_sites += 1
        off = s['file_offset']; va = s['va']
        check(va == text_vmaddr + off, f"{s['id']}: VA {va:#x} != __TEXT+{off:#x}")
        start = text_fileoff + off
        check(0 <= off < text_filesize, f"{s['id']}: file offset outside __TEXT")
        want = bytes.fromhex(s['bytes'])
        got = data[start:start + len(want)]
        check(got == want, f"{s['id']}: binary bytes {got.hex(' ')} != sites.json {s['bytes']}")
        raw, text_insn = at(va)
        check(raw == want, f"{s['id']}: objdump bytes {raw.hex(' ')} != sites.json {s['bytes']}")
        mnem = s['instruction'].split()[0]
        check(text_insn.split()[0] == mnem, f"{s['id']}: mnemonic mismatch ({text_insn!r})")
        # next instruction boundary
        i = va2idx[va]
        check(i + 1 < len(order), f"{s['id']}: no following instruction")
        nxt = order[i + 1]
        check(nxt == va + len(want), f"{s['id']}: instruction length disagrees with next boundary")
        check(nxt == text_vmaddr + s['next_instruction_file_offset'],
              f"{s['id']}: next boundary {nxt:#x} != recorded")
        # base register / BAR0 offset from the real text
        if s['kind'] != 'not_bar0':
            mem = parse_memop(text_insn)
            check(mem is not None, f"{s['id']}: no base+disp operand in {text_insn!r}")
            base, disp = mem
            check(base == s['base_register'], f"{s['id']}: base {base} != {s['base_register']}")
            check(disp + 0x1000 == s['bar0_offset'],
                  f"{s['id']}: disp {disp:#x}+0x1000 != BAR0 offset {s['bar0_offset']:#x}")
            pl = s['mmio_struct']['pointer_load_file_offset']
            check(pl is not None, f"{s['id']}: no pointer-load offset")
            praw, ptext = at(text_vmaddr + pl)
            pm = re.match(r'movq\s+(0x[0-9a-f]+)\(', ptext)
            check(pm is not None, f"{s['id']}: pointer load {ptext!r} is not movq disp(reg),reg")
            check(int(pm.group(1), 16) == s['mmio_struct']['pointer_field_offset'],
                  f"{s['id']}: pointer field mismatch")
            dst = ptext.rsplit(',', 1)[1].strip()
            check(dst == s['base_register'], f"{s['id']}: pointer-load dest {dst} != base {s['base_register']}")
        # patch span
        patch = s.get('patch')
        if patch:
            n_pat += 1
            span_starts.add(patch['span_start_file_offset'])
            span_start = text_vmaddr + patch['span_start_file_offset']
            check(span_start in insns, f"{s['id']}: span start not an instruction boundary")
            span_bytes = bytes.fromhex(patch['span_bytes'])
            check(len(span_bytes) >= 5, f"{s['id']}: patch span shorter than 5 bytes")
            check(len(span_bytes) == patch['span_length'], f"{s['id']}: span length mismatch")
            # walk whole instructions
            v = span_start; total = 0; orig = []
            for oi, orig_insn in enumerate(patch['original_instructions']):
                check(v == text_vmaddr + orig_insn['file_offset'],
                      f"{s['id']}: original instruction #{oi} offset mismatch")
                raw_i, txt_i = at(v)
                check(raw_i.hex(' ') == orig_insn['bytes'],
                      f"{s['id']}: original instruction {v:#x} bytes mismatch")
                check(txt_i == orig_insn['instruction'],
                      f"{s['id']}: original instruction {v:#x} text mismatch")
                total += len(raw_i); orig.append(raw_i)
                v = order[va2idx[v] + 1]
            check(total == patch['span_length'], f"{s['id']}: span does not tile whole instructions")
            check(b''.join(orig) == span_bytes, f"{s['id']}: span bytes != concatenated instructions")
            check(span_start == va or s['id'] == 'S10',
                  f"{s['id']}: span does not start at the site")
            end = span_start + total
            check(end == text_vmaddr + patch['next_after_span_file_offset'],
                  f"{s['id']}: span end {end:#x} is not the recorded next boundary")
            check(end in insns, f"{s['id']}: span end {end:#x} is not an instruction boundary in objdump")
            check(end in apv_addrs, f"{s['id']}: span end {end:#x} is not an instruction boundary in apv.dis")
            # no branch target inside the span (except its start)
            targets = set()
            for x in order:
                if not (text_vmaddr <= x < text_vmaddr + text_filesize): continue
                t = insns[x][1]
                if re.match(r'^j[a-z]+\s+0x[0-9a-f]+', t) or t.startswith('jmp '):
                    mm = re.search(r'0x[0-9a-f]+', t)
                    if mm: targets.add(int(mm.group(0), 16))
            v2 = span_start
            while v2 < end:
                raw_i, _ = at(v2)
                if v2 != span_start and v2 in targets:
                    fail(f"{s['id']}: branch target {v2:#x} inside patch span")
                v2 = order[va2idx[v2] + 1]
            # replacement template
            parts = patch['replacement'].split()
            check(parts[0] == 'e8' and parts[1:5] == ['xx'] * 4,
                  f"{s['id']}: replacement is not a near CALL rel32 template")
            check(len(parts) == patch['span_length'],
                  f"{s['id']}: replacement template length {len(parts)} != span {patch['span_length']}")
            check(all(p in ('xx', '90', '66') for p in parts[5:]), f"{s['id']}: bad padding")

    # ---- pointer-load table ----
    for p in sites['mmio_pointer_loads']:
        n_ptr += 1
        off = p['file_offset']; va = text_vmaddr + off
        raw, txt = at(va)
        check(raw.hex(' ') == p['bytes'], f"pointer load __TEXT+{off:#x}: bytes mismatch")
        check(txt == p['instruction'], f"pointer load __TEXT+{off:#x}: text mismatch")
        check(va + len(raw) == order[va2idx[va] + 1], f"pointer load __TEXT+{off:#x}: boundary mismatch")
        check(p['bar0_register_base_dest'] == txt.rsplit(',', 1)[1].strip(),
              f"pointer load __TEXT+{off:#x}: destination mismatch")
        check(va in apv_addrs, f"pointer load __TEXT+{off:#x} not in apv.dis")

    # ---- prior list verdicts ----
    for v in sites['prior_list_verdicts']:
        va = text_vmaddr + v['file_offset']
        listed = bytes.fromhex(v['listed_bytes'])
        check(v['bytes_match'], f"prior site __TEXT+{v['file_offset']:x}: bytes_match false")
        total = 0; v2 = va
        for ins in v['decoded']:
            raw, txt = at(v2)
            check(txt == ins, f"prior site __TEXT+{v['file_offset']:x}: decoded instruction mismatch")
            total += len(raw); v2 = order[va2idx[v2] + 1]
        check(total == len(listed), f"prior site __TEXT+{v['file_offset']:x}: listed byte length mismatch")
        check(insns[va][0].hex(' ') == ' '.join(f'{b:02x}' for b in listed[:len(insns[va][0])]),
              f"prior site __TEXT+{v['file_offset']:x}: first instruction bytes mismatch")
        if v['verdict'] == 'miscategorized':
            check('callq' in v['decoded'][0], 'miscategorized site must be the vtable call')

    # ---- coverage sanity ----
    cov = sites['coverage']
    check(cov['additional_bar0_sites_found'] == 0, 'coverage claims additional sites')
    check(len(sites['sites']) == 20, f"expected 20 instruction records, got {len(sites['sites'])}")
    check(n_pat == 8, f"expected 8 patch records (7 distinct spans), got {n_pat}")
    check(len(span_starts) == 7, f"expected 7 distinct patch spans, got {len(span_starts)}")
    kinds = {}
    for s in sites['sites']:
        kinds[s['classification']] = kinds.get(s['classification'], 0) + 1
    print(f'image: {args.image}')
    print(f'  UUID {macho["uuid"]}')
    print(f'  __TEXT vmaddr={text_vmaddr:#x} fileoff={text_fileoff:#x} size={text_filesize:#x}')
    print(f'  {len(order)} instruction boundaries (objdump), {len(apv_addrs)} also in apv.dis')
    print(f'sites.json: {n_sites} instruction sites, {n_ptr} MMIO pointer loads, '
          f'{n_pat} patch records ({len(span_starts)} distinct spans)')
    print(f'  classifications: {kinds}')
    print(f'  {checks} assertions passed')
    print('PASS: sites.json is consistent with the Mach-O, apv.dis and llvm-objdump')
    return 0

if __name__ == '__main__':
    sys.exit(main())
