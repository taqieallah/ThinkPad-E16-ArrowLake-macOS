#!/bin/bash
# Run every offline verification for the E16 APV live bridge and print a log.
# Run on the MacBook Air (Xcode + Rosetta 2 required for the stub simulator).
#
#   bash tooling/run-verification.sh [output-log]
set -uo pipefail
here="$(cd "$(dirname "$0")/.." && pwd)"
out="${1:-$here/VERIFICATION.log}"
fail=0

section() { echo; echo "############ $* ############"; }
check() {
    if "$@" >>"$out" 2>&1; then
        echo "PASS: $*"
    else
        echo "FAIL: $*"
        fail=1
    fi
}

: > "$out"
{
    echo "E16 APV live bridge — offline verification"
    echo "date: $(date)"
    echo "host: $(uname -a)"
    echo
} >> "$out"

section "1. Apple image identity"
check shasum -a 256 "$here/apv/com.apple.driver.AppleParavirtGPU"
check shasum -a 256 "/Volumes/1401/xegfx-e16/diag-25G241/com.apple.driver.AppleParavirtGPU"

section "2. Site plan against the real 25G241 Mach-O"
check python3 "$here/tooling/verify-sites.py"

section "3. Generated stubs, executed (Rosetta 2)"
check bash -c "cd '$here/tooling' && xcrun clang++ -arch x86_64 -std=c++17 -O1 -Wall -Wextra -Werror -I ../kext stub-sim.cpp -o stub-sim && arch -x86_64 ./stub-sim"

section "4. Kext build (x86_64, MacKernelSDK)"
rm -rf "$here/kext/build/ReimsPCIProbe.kext"
check bash -c "cd '$here/kext' && bash build.sh '$HOME/Downloads/ReimsPCIProbe/MacKernelSDK'"

section "5. Kext link check against the target boot collection"
check python3 "$HOME/src/kcabi/linkcheck.py" "$here/kext/build/ReimsPCIProbe.kext" \
    --kc /Volumes/1401/xegfx-e16/diag-25G241/BootKernelExtensions.kc \
    --baseline "$HOME/Documents/Codex/2026-11-15/new-chat-2/work/reference-0.1.10.kext"

section "6. Kext Mach-O shape and executable stub section"
check bash -c "cd '$here/kext' && xcrun lipo -verify_arch x86_64 build/ReimsPCIProbe.kext/Contents/MacOS/ReimsPCIProbe"
check bash -c "cd '$here/kext' && otool -l build/ReimsPCIProbe.kext/Contents/MacOS/ReimsPCIProbe | grep -A4 'sectname __apvstubs'"
check bash -c "cd '$here/kext' && nm build/ReimsPCIProbe.kext/Contents/MacOS/ReimsPCIProbe | grep -E ' _e16_apv_dispatch| gStubArea'"

section "7. Host daemon build and no-kext self-check (Rosetta 2)"
check bash -c "cd '$here/host' && bash build.sh"
check bash -c "cd '$here/host' && arch -x86_64 ./apv-host --no-arm --seconds 1"

section "8. Host daemon against the real Reims library"
check bash -c "cd '$here/host-proto' && arch -x86_64 ./reims-probe --phase main --registry-id 0x1000003de"

section "9. Package integrity"
pkgdir="$here/pkg/E16-APV-Live-0.2"
check bash -c "plutil -lint '$pkgdir/kext/ReimsPCIProbe.kext/Contents/Info.plist'"
check bash -c "for s in '$pkgdir'/scripts/*.sh; do bash -n \"\$s\" || exit 1; done"
check bash -c "for f in '$pkgdir/host/apv-host' '$pkgdir/host/lib/libreims_vgpu.dylib' '$pkgdir/tools/metal-registry'; do xcrun lipo -verify_arch x86_64 \"\$f\" || exit 1; done"
check bash -c "codesign --verify --strict '$pkgdir/host/apv-host' '$pkgdir/host/lib/libreims_vgpu.dylib' '$pkgdir/tools/metal-registry'"

echo
if [[ $fail -eq 0 ]]; then
    echo "RESULT: PASS (all sections ok); log: $out"
    exit 0
fi
echo "RESULT: FAIL; log: $out"
exit 1
